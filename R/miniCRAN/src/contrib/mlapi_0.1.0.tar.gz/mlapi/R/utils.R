raise_placeholder_error = function()
  stop("Placeholder for method. Subclasses should implement this method!")
