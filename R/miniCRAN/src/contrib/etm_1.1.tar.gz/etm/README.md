# etm

Non-parametric estimation of the matrix of transition probabilities for any time-inhomogeneous multistate model with finite state space.

