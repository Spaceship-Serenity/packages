library(testthat)
library(gam)

test_check("gam")
