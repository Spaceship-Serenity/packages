
context("prettycode")

test_that("prettycode works", {

  expect_true(TRUE)

})
