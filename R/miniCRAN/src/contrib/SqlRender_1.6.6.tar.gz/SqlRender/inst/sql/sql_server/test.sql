SELECT * FROM table;
