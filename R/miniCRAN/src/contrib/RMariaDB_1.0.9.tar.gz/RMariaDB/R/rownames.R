compatRowNames <- function(row.names) {
  if (is.null(row.names)) {
    row.names <- FALSE
  }

  row.names
}
