library(testthat)
library(RMariaDB)

test_check("RMariaDB")
