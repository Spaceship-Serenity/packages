#' @docType data
#' @title Sample data set
#' @name fish
#' @keywords data
#'
#' @description A sample data set, used in tests and some examples.
NULL


#' @docType data
#' @title Sample data set
#' @name qol_cancer
#' @keywords data
#'
#' @description A sample data set with longitudinal data, used in the vignette describing the \code{demean()} function.
NULL

