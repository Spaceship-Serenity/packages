#' Computer Modern font package
#'
#' This package contains the Computer Modern font with Paul Murrell's
#' symbol extensions. It is meant to be used with the fonts package.
#'
#'
#' @name fontcm
#' @docType package
#' @aliases fontcm package-fontcm
NULL
