library(testthat)
library(modelbased)

test_check("modelbased")
