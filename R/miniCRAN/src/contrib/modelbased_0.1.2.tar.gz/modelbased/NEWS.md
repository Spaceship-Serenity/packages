# modelbased 0.1.2

- Minor code changes to address changes from the forthcoming `parameters` package update.

# modelbased 0.1.1

- Fix CRAN check issues.

# modelbased 0.1.0

- Added a `NEWS.md` file to track changes to the package
