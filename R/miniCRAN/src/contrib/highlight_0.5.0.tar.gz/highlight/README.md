highlight
=========

<!-- badges: start -->
![R build status](https://github.com/hadley/highlight/workflows/R-CMD-check/badge.svg)
<!-- badges: end -->

Syntax highlighter for R based on [highlight](http://www.andre-simon.de/doku/highlight/en/highlight.html)

