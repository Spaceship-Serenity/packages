library(testthat)
library(mediation)

test_check("mediation")
