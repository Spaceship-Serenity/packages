"print.varstabil" <-
function(x, ...){
  print(x[[1]], ...)
}
