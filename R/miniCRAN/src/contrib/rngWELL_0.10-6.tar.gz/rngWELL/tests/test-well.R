library(rngWELL)
WELL2test(10)
