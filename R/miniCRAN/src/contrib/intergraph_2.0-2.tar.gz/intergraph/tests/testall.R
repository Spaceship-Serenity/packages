library(testthat)
library(intergraph)

test_package("intergraph")
