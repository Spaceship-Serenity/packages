#ifndef SPM_BLOCKSIZE_H_
#define SPM_BLOCKSIZE_H_


#define BLOCKSIZE 8


#endif
