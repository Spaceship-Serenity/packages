library(testthat)
library(smooth)

test_check("smooth")
