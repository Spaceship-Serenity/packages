library(testthat)
library(vipor)
test_check("vipor")
