require(PBSmapping) || stop("PBS Mapping library not available");

local({
   .PBSfig09()
});
