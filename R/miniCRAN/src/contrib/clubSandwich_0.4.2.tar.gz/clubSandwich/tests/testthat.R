library(testthat)
library(clubSandwich)

test_check("clubSandwich")
