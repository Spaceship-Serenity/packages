#include <Rinternals.h>	// for SEXP
extern SEXP address(SEXP x);
