library(testthat)
library(envnames)

test_check("envnames")
