# modeltests 0.1.2

* Extended the argument and column glossaries to accommodate changes in
the upcoming broom release.

# modeltests 0.1.1

* Fixes for tibble 3.0.0

# modeltests 0.1.0

* Added a `NEWS.md` file to track changes to the package.
