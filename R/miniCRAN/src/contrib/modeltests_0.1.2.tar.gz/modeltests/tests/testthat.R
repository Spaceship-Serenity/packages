library(testthat)
library(modeltests)

test_check("modeltests")
