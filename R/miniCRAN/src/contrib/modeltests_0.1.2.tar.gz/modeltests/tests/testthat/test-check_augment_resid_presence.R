context("test-check_augment_resid_presence")

# if the response is in the passed data and .fitted is in the BLAH,
# should get a .resid column

test_that("multiplication works", {
  expect_equal(2 * 2, 4)
})
