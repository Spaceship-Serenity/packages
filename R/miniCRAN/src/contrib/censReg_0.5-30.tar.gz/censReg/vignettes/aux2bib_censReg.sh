aux2bib censReg.aux
mv references.bib censReg.bib
