print.margEff.censReg <- function( x, ... ) {

   print.default( c( x ), ... )
   invisible( x )
}
