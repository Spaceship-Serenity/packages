nobs.censReg <- function( object, ... ) {
   return( unname( object$nObs[1] ) )
}