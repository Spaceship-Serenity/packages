print.summary.margEff.censReg <- function( x, ... ) {
   printCoefmat( x, ... )
   invisible( x )
}
