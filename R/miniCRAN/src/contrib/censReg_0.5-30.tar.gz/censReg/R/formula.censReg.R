formula.censReg <- function( x, ... ) {

   result <- formula( terms( x ) )

   return( result )
}
