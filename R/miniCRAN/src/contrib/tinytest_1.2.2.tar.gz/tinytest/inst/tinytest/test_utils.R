
expect_error(tinytest:::stopf("foo %s","bar"),"foo bar")

