#' A
#' @export
a <- function() {}

#' B
#' @export
b <- function() {}

#' C
#' @export
c <- function() {}
