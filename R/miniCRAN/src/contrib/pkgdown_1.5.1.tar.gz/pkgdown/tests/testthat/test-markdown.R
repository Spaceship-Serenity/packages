test_that("empty string works", {
  expect_equal(markdown_text(""), "")
})
