context("droplet_create")

# test_that("returns expected output", {
#   skip_on_cran()

#   x <- droplet_create()

#   expect_is(siz, "data.frame")
# })

# test_that("xxxxx", {
#   skip_on_cran()

#   library("httr")
#   expect_error(sizes(config = timeout(seconds = 0.001)))
# })
