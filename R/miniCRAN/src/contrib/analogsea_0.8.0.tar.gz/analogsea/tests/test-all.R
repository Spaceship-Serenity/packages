library(testthat)
test_check("analogsea")
