## ----setup, include = FALSE----------------------------------------------
library(knitr)
opts_chunk$set(warning = FALSE, message = FALSE, fig.pos = "h")

## ---- eval=FALSE---------------------------------------------------------
#  install.packages("memor")
#  
#  # For dev version
#  devtools::install_github("hebrewseniorlife/memor")

