# not really meant to run tests, just force the .Rcheck folder to have a tests
# subfolder

TRUE
