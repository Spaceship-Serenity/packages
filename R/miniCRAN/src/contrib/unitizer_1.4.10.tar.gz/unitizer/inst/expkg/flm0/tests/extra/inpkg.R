# should fail normally, but return TRUE if run in fastlm
library(utzflm, lib.loc=getOption('unitizer.tmp.lib.loc'))
hidden_fun()
