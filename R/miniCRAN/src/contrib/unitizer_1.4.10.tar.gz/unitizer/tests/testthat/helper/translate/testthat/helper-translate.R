# helper functions for translate tests

fun0 <- function(...) 42
fun1 <- function(...) 24
