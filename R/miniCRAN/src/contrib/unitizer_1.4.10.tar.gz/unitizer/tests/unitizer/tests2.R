set.seed(1, kind="Wichmann-Hill")
1 + 1
print("heya")
stop("wow")
matrix(runif(21), nrow=3)
lm(x ~ y, data.frame(x=1:10, y=2 * (1:10)))
warning("this is a warning\nthat\nspans\nmany\nlines")
data.frame(
  a=1:20,
  b=letters[1:20],
  stringsAsFactors=FALSE
)
