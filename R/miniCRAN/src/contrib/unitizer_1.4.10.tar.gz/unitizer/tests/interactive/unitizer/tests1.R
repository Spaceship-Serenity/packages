1 + 1
print("heya")
stop("wow")
matrix(runif(21), nrow=3)
warning("this is a warning")
for(i in 1:3) {
  warning("warning #", j)
}
data.frame(
  a=1:10,
  b=letters[1:10]
)
{
  print("this is a test")
  warning("ouch")
  print("another test")
}
