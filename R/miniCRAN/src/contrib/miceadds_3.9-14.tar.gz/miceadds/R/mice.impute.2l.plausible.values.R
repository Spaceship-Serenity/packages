## File Name: mice.impute.2l.plausible.values.R
## File Version: 1.24
mice.impute.2l.plausible.values <- function(...){
    .Defunct(new="mice.impute.plausible.values", package="miceadds")
}
