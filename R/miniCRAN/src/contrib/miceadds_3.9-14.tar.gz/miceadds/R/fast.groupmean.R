## File Name: fast.groupmean.R
## File Version: 1.02
fast.groupmean <- function(...){
    .Defunct(new="GroupMean", package="miceadds")
}
