## File Name: mice.impute.2lonly.norm2.R
## File Version: 1.03

mice.impute.2lonly.norm2 <- function(...){
    .Defunct(new="mice::mice.impute.2lonly.norm", package="miceadds")
}
