## File Name: ma_colMeans.R
## File Version: 0.01

ma_colMeans <- function(x)
{
    colMeans(x=x, na.rm=TRUE)
}
