## File Name: mice.impute.2lonly.pmm2.R
## File Version: 0.10

mice.impute.2lonly.pmm2 <- function(...){
    .Defunct(new="mice::mice.impute.2lonly.pmm", package="miceadds")
}

