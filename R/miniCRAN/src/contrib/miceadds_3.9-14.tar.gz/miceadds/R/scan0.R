## File Name: scan0.R
## File Version: 0.14


# scan function with default what="character"
scan0 <- function( file="", ...)
{
    scan( file=file, what="character", ...)
}
