## File Name: require_namespace.R
## File Version: 0.02

require_namespace <- function(pkg)
{
    requireNamespace(package=pkg)
}
