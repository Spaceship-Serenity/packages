## File Name: fast.groupsum.R
## File Version: 1.03

fast.groupsum <- function(...){
    .Defunct(new="GroupSum", package="miceadds")
}
