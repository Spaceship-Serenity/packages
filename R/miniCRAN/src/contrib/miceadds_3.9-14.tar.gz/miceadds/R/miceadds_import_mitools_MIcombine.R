## File Name: miceadds_import_mitools_MIcombine.R
## File Version: 0.06

miceadds_import_mitools_MIcombine <- function(...)
{
    res <- mitools::MIcombine(...)
    return(res)
}
