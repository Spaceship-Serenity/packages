## File Name: miceadds_import_mitools_imputationList.R
## File Version: 0.05

miceadds_import_mitools_imputationList <- function(...)
{
    res <- mitools::imputationList(...)
    return(res)
}
