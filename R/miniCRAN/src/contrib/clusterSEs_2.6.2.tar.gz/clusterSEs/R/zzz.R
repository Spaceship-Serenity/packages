.onAttach <- function(libname, pkgname) {
  packageStartupMessage("\n When using this package, cite: \n \n Justin Esarey and Andrew Menger (2019). \n \"Practical and Effective Approaches to Dealing with Clustered Data.\" \n Political Science Research and Methods 7(3): 541-549. \n URL: https://doi.org/10.1017/psrm.2017.42. \n")
}