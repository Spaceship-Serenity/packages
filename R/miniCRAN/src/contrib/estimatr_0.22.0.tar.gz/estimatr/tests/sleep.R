library(estimatr)
lm_robust(extra~group, sleep)
