library(testthat)
library(foghorn)

test_check("foghorn")
