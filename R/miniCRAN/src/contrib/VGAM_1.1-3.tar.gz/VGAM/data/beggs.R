beggs <-
structure(list(e0 = c(254, 34, 8, 0, 1), e1 = c(115, 29, 8, 0, 
1), e2 = c(42, 16, 3, 4, 1), e3 = c(13, 6, 3, 1, 0), e4 = c(6, 
1, 1, 1, 0)), .Names = c("e0", "e1", "e2", "e3", "e4"), row.names = c("b0", 
"b1", "b2", "b3", "b4"), class = "data.frame")
