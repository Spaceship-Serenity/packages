finney44 <-
structure(list(pconc = c(0, 0.0025, 0.005, 0.01, 0.025, 0.05), 
    hatched = c(44, 19, 17, 13, 2, 0), unhatched = c(55, 32, 
    32, 38, 46, 50)), .Names = c("pconc", "hatched", "unhatched"
), row.names = c(NA, -6L), class = "data.frame")
