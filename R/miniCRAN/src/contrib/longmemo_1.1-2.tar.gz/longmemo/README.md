The main purpose of this R package `longmemo` (and its predecessing S-plus scripts)
has always been to provide

- primarily the data sets
- less importantly the code from chapter 12

of the book

	@Book{BerJ94,
	  author = 	 {Jan Beran},
	  title = 	 {Statistics for Long-Memory Processes},
	  publisher = {Chapman \& Hall},
	  year = 	 1994,
	  series =	 {Monographs on Statistics and Applied Probability 61},
	  address =	 NY
	}

Jan Beran sent the necessary files to me (by e-mail on 1995-09-15)
with explicit consent to make them available electronically.

			 Martin Maechler <maechler@stat.math.ethz.ch>
			 Sept.1995;  April, August 2002

