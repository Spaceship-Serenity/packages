# lpSolveAPI

The **lpSolveAPI** package was created by Kjell Konis, I currently maintain the package.
**lpSolveAPI** provides an interface to [`lp_solve`](https://sourceforge.net/projects/lpsolve)
which was last updated 2016. Therefore if you don't need callbacks it is recommended 
to use **ROI** ([`https://cran.r-project.org/package=ROI`](https://cran.r-project.org/package=ROI), [`http://roi.r-forge.r-project.org/`](http://roi.r-forge.r-project.org/)) instead.
