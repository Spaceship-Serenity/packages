library(testthat)
library(docopt)

test_check("docopt")