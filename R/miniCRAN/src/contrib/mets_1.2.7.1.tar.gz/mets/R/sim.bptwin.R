##' @export
simulate.bptwin <- function(object,nsim=100,seed=NULL,P,...) {
  return(object)
}
