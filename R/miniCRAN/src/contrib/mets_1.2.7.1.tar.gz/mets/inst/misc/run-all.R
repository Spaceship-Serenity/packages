library(testthat)
library(mets)

test_packages("mets")
