library("testthat")
test_check("partitions")
