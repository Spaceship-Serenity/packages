### R code from vignette source 'actuar.Rnw'

###################################################
### code chunk number 1: actuar.Rnw:106-108 (eval = FALSE)
###################################################
## vignette(package = "actuar")
## demo(package = "actuar")


###################################################
### code chunk number 2: actuar.Rnw:117-119 (eval = FALSE)
###################################################
## citation()
## citation("actuar")


