
# Rcsdp

<!-- badges: start -->
<!-- badges: end -->

This package is an R interface to the CSDP semidefinite programming library by Brian Borchers (https://projects.coin-or.org/Csdp/)

## Installation

You can install the released version of Rcsdp from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("Rcsdp")
```



