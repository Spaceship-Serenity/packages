globalVariables(c(".", "gutenberg_id", "language", "has_text",
                  "gutenberg_metadata", "number", "total"))
