library(testthat)
library(pivottabler)

test_check("pivottabler", filter="C-")
