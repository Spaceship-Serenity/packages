library(testthat)
library(measures)

test_check("measures")
