# `networkDynamic`:  Dynamic Extensions for Network Objects

[![Build Status](https://travis-ci.org/statnet/networkDynamic.svg?branch=master)](https://travis-ci.org/statnet/networkDynamic)
[![Build Status](https://ci.appveyor.com/api/projects/status/rmj7f1xmpikh2243?svg=true)](https://ci.appveyor.com/project/statnet/networkDynamic)
[![rstudio mirror downloads](http://cranlogs.r-pkg.org/badges/networkDynamic?color=2ED968)](http://cranlogs.r-pkg.org/)
[![cran version](http://www.r-pkg.org/badges/version/networkDynamic)](https://cran.r-project.org/package=networkDynamic)

Simple interface routines to facilitate the handling of network objects with complex intertemporal data. This is a part of the "statnet" suite of packages for network analysis.
