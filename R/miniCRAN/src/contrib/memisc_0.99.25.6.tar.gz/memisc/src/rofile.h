FILE *rofile_FILE(SEXP s_file);
