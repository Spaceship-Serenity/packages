library(testthat)
library(anyLib)

test_check("anyLib")
