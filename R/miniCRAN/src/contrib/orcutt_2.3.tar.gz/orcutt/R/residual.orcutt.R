residual.orcutt <-
function(object, ...){
  return(object$residuals)
}
