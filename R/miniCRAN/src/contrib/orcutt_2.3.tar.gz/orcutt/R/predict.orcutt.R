predict.orcutt <-
function(object, ...){
  return(object$fitted.values)
}
