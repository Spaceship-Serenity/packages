#!/bin/bash
aux2bib systemfit.aux
bibsort references.bib >systemfit.bib
