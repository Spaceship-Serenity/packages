### nobs.R --- 
##----------------------------------------------------------------------
## Author: Brice Ozenne
## Created: maj  2 2018 (09:15) 
## Version: 
## Last-Updated: maj  2 2018 (09:17) 
##           By: Brice Ozenne
##     Update #: 2
##----------------------------------------------------------------------
## 
### Commentary: 
## 
### Change Log:
##----------------------------------------------------------------------
## 
### Code:

## not defined by lava
nobs.lvmfit <- function(object){
    return(object$data$n)
}

######################################################################
### nobs.R ends here
