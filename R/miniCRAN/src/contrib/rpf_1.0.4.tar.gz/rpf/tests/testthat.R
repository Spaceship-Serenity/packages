library(testthat)
library(rpf)

test_check("rpf")
