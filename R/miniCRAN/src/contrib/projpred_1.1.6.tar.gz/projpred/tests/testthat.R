library(testthat)
library(projpred)

test_check("projpred")
