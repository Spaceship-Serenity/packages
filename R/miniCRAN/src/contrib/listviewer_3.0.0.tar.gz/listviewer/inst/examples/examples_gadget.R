\dontrun{
library(listviewer)

jsonedit_gadget(
  structure(
    as.list(1:4),
    names=letters[1:4]
  )
)
}
