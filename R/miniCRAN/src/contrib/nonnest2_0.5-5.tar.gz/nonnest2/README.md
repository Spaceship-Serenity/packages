# nonnest2

nonnest2 provides functionality for comparing non-nested models' fit and distinguishability, relying on theory from Vuong (1989).  The authors acknowledge support from NSF grant SES-1061334.  The contents of this package are those of the authors and do not reflect the views of the National Science Foundation.
