library(testthat)
library(nonnest2)

test_check("nonnest2")
