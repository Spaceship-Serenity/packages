#' @export
print.glmfm <- function(x, digits = max(3, getOption("digits") - 3), ...)
  print.lmfm(x, digits = digits, ...)


