# rcheology 4.0.2.0

* New data for R 4.0.2


# rcheology 4.0.1.0

* New data for R 4.0.1
* Compact display, new "first version" & "last version" columns in Shiny app

# rcheology 4.0.0.0

* New data for R 4.0.0
* Congratulations to the R Core Team, and everyone who made R what it is today!

# rcheology 3.6.3.0

* New data for R 3.6.3

# rcheology 3.6.2.0

* New data for R 3.6.2

# rcheology 3.6.1.0

* New data for R 3.6.1

# rcheology 3.6.0.0

* New data for R 3.6.0

# rcheology 3.5.3.0

* New data for R 3.5.3
* Update `Rversions` data

# rcheology 3.5.2.0

* New data for R 3.5.2

# rcheology 3.5.1.1

* Include R functions from R 1.0.1 onwards. Compiled on Debian Woody and Sarge.
* Removed releases of "recommended" packages from the Rversions data frame.
* Include objects whose names start with a `.`.
* New column "exported" reports whether object was found in `getNamespaceExports()`.

# rcheology 3.5.1.0

* Added a `NEWS.md` file to track changes to the package.
