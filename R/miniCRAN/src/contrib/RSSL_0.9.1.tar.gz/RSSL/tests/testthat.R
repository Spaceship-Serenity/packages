library(testthat)
library(RSSL)
test_check("RSSL")