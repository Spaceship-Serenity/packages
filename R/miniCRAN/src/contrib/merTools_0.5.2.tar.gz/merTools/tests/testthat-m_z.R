library(testthat)
library(merTools)


test_check("merTools", filter = "^[m-z]")
