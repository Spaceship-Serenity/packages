library(testthat)
library(merTools)

test_check("merTools")
