library(testthat)
library(BradleyTerry2)

test_check("BradleyTerry2")