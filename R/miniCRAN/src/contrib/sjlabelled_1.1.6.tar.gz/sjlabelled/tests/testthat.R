library(testthat)
library(sjlabelled)

test_check("sjlabelled")
