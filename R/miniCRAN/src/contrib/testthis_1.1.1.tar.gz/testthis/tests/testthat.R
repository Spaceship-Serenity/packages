library(testthat)

test_check("testthis")
