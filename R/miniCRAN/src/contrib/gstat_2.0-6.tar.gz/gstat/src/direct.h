double valid_direction(DPOINT *a, DPOINT *b, int symmetric, const DATA *d);
void set_direction_values(double a, double b, double t_h, double t_v);
