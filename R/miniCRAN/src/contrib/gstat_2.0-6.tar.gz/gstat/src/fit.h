#ifndef FIT_H
# define FIT_H

#if defined(__cplusplus)
extern "C" {
#endif

int fit_variogram(VARIOGRAM *v);

#if defined(__cplusplus)
}
#endif

#endif
