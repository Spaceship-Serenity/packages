int select_at(DATA *d, DPOINT *where);
