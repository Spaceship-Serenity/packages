#' @format NULL
spec_connection <- c(
  spec_connection_disconnect,
  spec_connection_data_type,
  spec_connection_get_info
)
