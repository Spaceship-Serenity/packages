spec_all <- c(
  spec_getting_started,
  spec_driver,
  spec_connection,
  spec_result,
  spec_sql,
  spec_meta,
  spec_transaction,
  spec_compliance,
  spec_stress
)
