library(testthat)
library(DBItest)

test_check("DBItest")
