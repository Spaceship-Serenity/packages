SimCiDiff <-
function(...) UseMethod("SimCiDiff")
