SimCiRat <-
function(...) UseMethod("SimCiRat")
