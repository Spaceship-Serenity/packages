SimTestRat <-
function(...) UseMethod("SimTestRat")
