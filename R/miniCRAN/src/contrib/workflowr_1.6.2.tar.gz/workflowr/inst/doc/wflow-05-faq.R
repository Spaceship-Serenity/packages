## ----render-single-page, eval=FALSE-------------------------------------------
#  library("rmarkdown")
#  # Create analysis/file.html
#  render("analysis/file.Rmd", html_document())
#  # Create analysis/file.pdf
#  render("analysis/file.Rmd", pdf_document())

