## ----chunk-options, include=FALSE---------------------------------------------
library("knitr")
opts_chunk$set(eval = FALSE)

## ----knit-expand-vignette-----------------------------------------------------
#  vignette("knit_expand", package = "knitr")

