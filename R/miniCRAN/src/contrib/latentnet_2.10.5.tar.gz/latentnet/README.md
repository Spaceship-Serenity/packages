# `latentnet`: Latent Position and Cluster Models for Statistical Networks

[![Build Status](https://travis-ci.org/statnet/latentnet-private.svg?branch=master)](https://travis-ci.org/statnet/latentnet-private)<!-- [![Build Status](https://ci.appveyor.com/api/projects/status/cvdxnhu5mnlj8vg2?svg=true)](https://ci.appveyor.com/project/statnet/latentnet-private) -->
[![rstudio mirror downloads](http://cranlogs.r-pkg.org/badges/latentnet?color=2ED968)](http://cranlogs.r-pkg.org/)
[![cran version](http://www.r-pkg.org/badges/version/latentnet)](https://cran.r-project.org/package=latentnet)



Fit and simulate latent position and cluster models for statistical networks. 
