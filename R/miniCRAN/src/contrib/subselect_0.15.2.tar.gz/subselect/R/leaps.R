
leaps<-function(...) eleaps(...)

