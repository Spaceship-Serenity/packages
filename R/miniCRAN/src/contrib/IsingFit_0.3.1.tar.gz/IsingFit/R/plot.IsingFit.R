plot.IsingFit <-
function(x,...) qgraph(x$q,DoNotPlot = FALSE, ...)
