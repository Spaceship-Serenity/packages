coef.weibull.frailty <-
function (object, ...) {
    object$coefficients$betas
}
