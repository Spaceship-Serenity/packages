prederrJM <-
function (object, newdata, Tstart, Thoriz, ...) {
    UseMethod("prederrJM")
}
