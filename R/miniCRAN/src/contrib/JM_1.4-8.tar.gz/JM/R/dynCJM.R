dynCJM <-
function (object, newdata, Dt, ...) {
    UseMethod("dynCJM")
}
