aucJM <-
function (object, newdata, Tstart, ...) {
    UseMethod("aucJM")
}
