
if (getRversion() >= '2.15.1') globalVariables(c('X', 'Xtime', 'WW', 'gammas', 'parameterization', 'Xs', 'Zsb', 'Ws.intF.vl', 'alpha', 'Xs.deriv', 'indFixed', 'Zsb.deriv',
'Ws.intF.sl', 'Dalpha', 'wk', 'P', 'XtX', 'sigma', 'id.GK', 'd', 'sigma.t', 'ncx', 'p.byt', 'wGH', 'eta.tw', 'xi', 'ind.K', 'wkP', 'eta.tw1', 'eta.ws', 'idT', 'log.st',
'lambda0.', 'indT', 'p.byt.', 'ncww', 'diag.D', 'Xtime2', 'Ztime.b', 'Ztime2.b', 'n', 'Ztb', 'y', 'id', 'ind.T0', 'k', 'unq.indT', 'ind.L1', 'control', 'b', 'ncz', 'lis.b',
'VCdets', 'list.thetas', 'WintF.vl', 'Xtime.deriv', 'Ztime.b.deriv', 'WintF.sl', 'ind.D', 'W1', 'W2', 'W2s', 'scaleWB', 'logT', 'object', 'obs.times', 'Z', 'LongFormat',
'Ztime', 'Ztime.deriv', 'method', 'Zs', 'Zs.deriv', 'st', 'type', 'M', 'return.data', 'ni', 'data.id', 'timeVar', 'TermsX', 'TermsZ', 'formYx', 'formYz', 'TermsX.deriv',
'TermsZ.deriv', 'derivForm', 'Q', 'betas.new', 'indRandom', 'alpha.new', 'Dalpha.new', 'W', 'gammas.new', 'sigma.t.new', 'strt', 'gammas.bs.new', 'i', 'xi.new', 'lambda0',
'b2', 'lis.b2', 'ZtZ', 'N', 'nk', 'B', 'verbose', 'Ys.deriv', 'eta.yxi', 'Z.ind.i', 'eta.si', 'Zsi', 'GKk', 'yi', 'eta.tw1i', 'eta.tw2i', 'eta.yxT', 'Ztime.i', 'Pi',
'eta.wsi', 'yi.eta.yxi', 'Zb', 'Y', 'Y.deriv', 'Ys', 'Y2', 'chLaplace.fit', 'sigma.new', 'D.new', 'eta.tw2', 'eta.yx', 'Z.missO', 'id3.miss', 'y.missO', 'id.miss', 'n.missO',
'Xtime.missO', 'Ztime.missO', 'WintF.vl.missO', 'Xs.missO', 'Zs.missO', 'Ws.intF.vl.missO', 'Xtime.deriv.missO', 'Ztime.deriv.missO', 'WintF.sl.missO', 'Xs.deriv.missO',
'Zs.deriv.missO', 'Ws.intF.sl.missO', 'logT.missO', 'log.st.missO', 'P.missO', 'd.missO', 'W2.missO', 'idT.missO', 'W2s.missO', 'ind.D.missO', 'ind.K.missO', 'wkP.missO',
'max.time', 'SclongCH', 'ScsurvCH', 'update.bCH', 'LogLik.chLaplace', 'Score.chLaplace', 'kn', 'new.b', 'cons.logLik', 'xtable', 'pdMatrix'))
