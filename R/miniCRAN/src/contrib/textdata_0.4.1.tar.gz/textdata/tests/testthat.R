library(testthat)
library(textdata)

test_check("textdata")
