alkfos <- read.csv("alkfos.csv")
