### exstracts the independent components of an ics object
###
###

`ics.components` <-
function(object)
     {
    return(object@Scores)
    }
