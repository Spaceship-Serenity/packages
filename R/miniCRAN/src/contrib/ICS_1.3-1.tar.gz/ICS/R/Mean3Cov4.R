Mean3Cov4  <- function(x) list(location = mean3(x), scatter = cov4(x))
