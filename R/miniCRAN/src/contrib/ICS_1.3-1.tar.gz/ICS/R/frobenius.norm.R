### internal function for the frobenius norm of a matrix
###
###

`frobenius.norm` <-
function(A)
    {
    sqrt(sum(A^2))
    }
