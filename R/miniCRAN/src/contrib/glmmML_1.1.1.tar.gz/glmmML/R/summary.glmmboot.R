summary.glmmboot <- function(object, ...){
    print.glmmboot(object, ...)
}
