.onLoad <- function(libname, pkgname){
  setDefaultFrequencies(setup = TRUE)
}
