Lag <- function(x, k = 1, ...) lag(x, -k, ...)
