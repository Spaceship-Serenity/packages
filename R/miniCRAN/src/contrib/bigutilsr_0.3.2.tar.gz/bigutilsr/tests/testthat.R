library(testthat)
library(bigutilsr)

test_check("bigutilsr")
