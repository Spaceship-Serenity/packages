/* $Id$ */
# include "cppad/check_numeric_type.hpp"
