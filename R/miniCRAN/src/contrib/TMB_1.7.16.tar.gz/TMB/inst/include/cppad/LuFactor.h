/* $Id$ */
# include "cppad/lu_factor.hpp"
