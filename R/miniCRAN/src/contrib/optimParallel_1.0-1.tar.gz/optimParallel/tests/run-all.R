library(testthat)
test_check('optimParallel')
