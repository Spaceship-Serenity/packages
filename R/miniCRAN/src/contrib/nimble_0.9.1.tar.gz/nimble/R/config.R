NeedMakevarsFile = TRUE
UseLibraryMakevars = TRUE
.NimbleUseRegistration = TRUE


