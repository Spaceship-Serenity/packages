library(testthat)
library(rcartocolor)

test_check("rcartocolor")
