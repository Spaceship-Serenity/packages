
trace <- function(mat){
  sum(diag(mat))
}
