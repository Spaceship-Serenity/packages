suppressPackageStartupMessages(library("testthat"))
test_check("gof")
