caSupplementalElementsPreProcessing <- function(SUP.DATA){

	return(rowNorms(SUP.DATA,'ca'))
	
}