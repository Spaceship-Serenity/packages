Ecfun 0.2-2

testURLs and read.testURLs have been removed, 
because it wasn't clear that anyone was using them, 
and more modern tools are available from:  
http://www.measurementlab.net/
