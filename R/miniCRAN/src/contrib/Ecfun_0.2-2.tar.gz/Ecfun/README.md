# Ecfun 
# 2020-01-23
testURLs and read.testURLs have been removed, 
because it wasn't clear that anyone was using them, 
and more modern tools are available from:  
http://www.measurementlab.net/

Thanks to Iñaki Ucar, Adam H Sparks, and Roy 
Mendelssohn for their replies to a question 
posted to R-Devel helped me understand what 
I needed to do to fix problems identified in 
the CRAN Checks.
