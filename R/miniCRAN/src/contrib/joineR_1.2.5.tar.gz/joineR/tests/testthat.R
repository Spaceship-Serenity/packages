library(testthat)
library(joineR)

test_check("joineR")
