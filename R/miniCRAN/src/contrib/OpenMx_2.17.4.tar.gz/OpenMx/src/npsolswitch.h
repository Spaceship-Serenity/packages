#define HAS_NPSOL 0
