plot.EDAM <- function(...) shardsplot(...)
