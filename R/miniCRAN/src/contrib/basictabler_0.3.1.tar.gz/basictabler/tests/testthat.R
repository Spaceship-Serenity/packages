library(testthat)
library(basictabler)

test_check("basictabler")

