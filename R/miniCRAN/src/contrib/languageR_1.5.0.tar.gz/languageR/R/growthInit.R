`growthInit` <-
function(data) new("growth", data=data)

