aovlmer.fnc <- function (object, ...) 
{
  stop("This function no longer works with lme4 versions >= 1.0.4
       For p-values, use the anova() function in the lmerTest package.")
}
