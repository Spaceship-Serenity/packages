library(testthat)
library(feisr)

test_check("feisr")
