epi.supc <- function(treat, control, sd, delta, n, r = 1, power, alpha){
  .Deprecated(old = "epi.supc", new = "epi.sssupc")
}   
