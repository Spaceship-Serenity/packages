"epi.cluster1size" <- function(n, mean, var, epsilon.r, method = "mean", conf.level = 0.95){
  .Deprecated(old = "epi.cluster1size", new = "epi.ssclus1estc")
}
