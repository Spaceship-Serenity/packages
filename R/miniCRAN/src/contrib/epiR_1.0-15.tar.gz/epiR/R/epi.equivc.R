epi.equivc <- function(treat, control, sd, delta, n, r = 1, power, alpha){
  .Deprecated(old = "epi.equivc", new = "epi.ssequc")
}  
