epi.supb <- function(treat, control, delta, n, r = 1, power, alpha){
  .Deprecated(old = "epi.supb", new = "epi.sssupb")
}  
