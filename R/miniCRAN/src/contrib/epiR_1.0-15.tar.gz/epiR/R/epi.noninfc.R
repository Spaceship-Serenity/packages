epi.noninfc <- function(treat, control, sd, delta, n, r = 1, power, alpha){
  .Deprecated(old = "epi.noninfc", new = "epi.ssnoninfc")
}  
