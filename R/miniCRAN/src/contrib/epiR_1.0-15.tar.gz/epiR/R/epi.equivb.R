epi.equivb <- function(treat, control, delta, n, r = 1, power, alpha){
  .Deprecated(old = "epi.equivb", new = "epi.ssequb")
}  
