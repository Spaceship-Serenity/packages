epi.detectsize <- function(N, prev, se, sp, interpretation = "series", covar = c(0,0), conf.level = 0.95, finite.correction = TRUE){
  .Deprecated(old = "epi.detectsize", new = "epi.ssdetect")
}
