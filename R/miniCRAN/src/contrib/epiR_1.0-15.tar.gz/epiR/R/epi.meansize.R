"epi.meansize" <- function(treat, control, n, sigma, power, r = 1, design = 1, sided.test = 2, conf.level = 0.95) {
  .Deprecated(old = "epi.meansize", new = "epi.sscompc")
}
