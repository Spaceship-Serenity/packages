"epi.cluster2size" <- function(nbar, R = NA, n, mean, sigma2.x, sigma2.y = NA, sigma2.xy = NA, epsilon.r, method = "mean", conf.level = 0.95){
  .Deprecated(old = "epi.cluster2size", new = "epi.ssclus2estc")
}
