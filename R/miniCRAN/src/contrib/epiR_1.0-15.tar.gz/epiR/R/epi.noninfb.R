epi.noninfb <- function(treat, control, delta, n, r = 1, power, alpha){
  .Deprecated(old = "epi.noninfb", new = "epi.ssnoninfb")
}  
