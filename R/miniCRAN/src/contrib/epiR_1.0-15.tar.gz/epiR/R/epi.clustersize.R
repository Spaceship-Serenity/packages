"epi.clustersize" <- function(p, b, rho, epsilon.r, conf.level = 0.95){
  .Deprecated(old = "epi.clustersize", msg = "epi.clustersize is deprecated")
}
