"epi.survivalsize" <- function(treat, control, n, power, r = 1, design = 1, sided.test = 2, conf.level = 0.95) {
  .Deprecated(old = "epi.survivalsize", new = "epi.sscomps")
  }
