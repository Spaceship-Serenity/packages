epi.stratasize <- function (strata.n, strata.mean, strata.var, strata.Py, epsilon.r, method = "mean", conf.level = 0.95){
  .Deprecated(old = "epi.stratasize", new = c("epi.ssstrataestb","epi.ssstrataestc"))
}
