"epi.ccsize" <- function(OR, p0, n, power, r = 1, rho = 0, design = 1, sided.test = 2, conf.level = 0.95, method = "unmatched", fleiss = FALSE){
  .Deprecated(old = "epi.ccsize", new = "epi.sscc")
}
