"epi.cohortsize" <- function(exposed, unexposed, n, power, r = 1, design = 1, sided.test = 2, conf.level = 0.95) {
  .Deprecated(old = "epi.cohortsize", new = "epi.sscohort")
}