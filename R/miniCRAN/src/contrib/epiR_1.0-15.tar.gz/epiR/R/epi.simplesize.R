epi.simplesize <- function(N = 1E+06, Vsq, Py, epsilon.r, method = "mean", conf.level = 0.95){
  .Deprecated(old = "epi.simplesize", new = c("epi.sssimpleestb","epi.sssimpleestc"))
}
