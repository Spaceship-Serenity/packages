"epi.propsize" <- function(treat, control, n, power, r = 1, design = 1, sided.test = 2, conf.level = 0.95) {
  .Deprecated(old = "epi.propsize", new = "epi.sscompb")
}
