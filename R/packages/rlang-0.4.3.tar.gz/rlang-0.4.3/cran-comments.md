
This is a resubmission of 0.4.3.

## Test environments

* local OS X install: release
* travis-ci: 3.2, 3.3, 3.4, 3.5, release, and devel
* win-builder: devel and release
* rchk: unbuntu-rchk platform on R-hub


## R CMD check results

0 errors | 0 warnings | 0 notes


## Reverse dependencies

I have run R CMD check on the downstream dependencies. (Summary at https://github.com/tidyverse/rlang/tree/master/revdep).

I couldn't install 14 packages. There were no problems.
