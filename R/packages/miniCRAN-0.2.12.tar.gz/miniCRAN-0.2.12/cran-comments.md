This is a bug fix release of miniCRAN.

## Test environments

* local Windows install, R-3.6.1
* ubuntu trusty 14.04 (on travis-ci), testing on:
  - R-release
  - R-oldrel
  - R-devel
* XCode (Mac OS) (on travis-ci)

## R CMD check results

There were no ERRORs, WARNINGs or NOTEs.


## Downstream dependencies

`miniCRAN` has only one reverse dependency, `AzureML`, and all tests pass