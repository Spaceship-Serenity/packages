
## Test environments

* local OS X install: release
* travis-ci: 3.2, 3.3, 3.4, 3.5, release, and devel
* win-builder: devel and release
* rchk: unbuntu-rchk platform on R-hub


## R CMD check results

0 errors | 0 warnings | 0 notes


## Reverse dependencies

ggplot2 is failing because of faulty assumptions in unit tests. We'll submit an update shortly.

Apart from this, no problems were found.
