## Test environments
* GitHub Actions (ubuntu-16.04): 3.3, 3.4, 3.5, oldrel, release, devel
* GitHub Actions (windows): release, 3.6
* Github Actions (macOS): release, devel
* win-builder: devel

## R CMD check results

0 errors | 0 warnings | 0 notes

## Downstream dependencies

I ran `R CMD check` on all 12 reverse dependencies
(https://github.com/r-lib/pkgbuild/tree/master/revdep). There were no
regressions.
