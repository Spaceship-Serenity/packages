# Platform

|field    |value                        |
|:--------|:----------------------------|
|version  |R version 3.6.0 (2019-04-26) |
|os       |macOS Mojave 10.14.4         |
|system   |x86_64, darwin15.6.0         |
|ui       |X11                          |
|language |(EN)                         |
|collate  |en_US.UTF-8                  |
|ctype    |en_US.UTF-8                  |
|tz       |America/New_York             |
|date     |2019-08-05                   |

# Dependencies

|package  |old   |new        |Δ  |
|:--------|:-----|:----------|:--|
|pkgbuild |1.0.3 |1.0.3.9000 |*  |
|callr    |NA    |3.3.1      |*  |
|processx |NA    |3.4.1      |*  |

# Revdeps

## Failed to check (3)

|package   |version |error |warning |note |
|:---------|:-------|:-----|:-------|:----|
|codemetar |0.1.8   |1     |        |1    |
|ctsem     |3.0.0   |1     |        |2    |
|jwutil    |1.2.3   |1     |        |     |

