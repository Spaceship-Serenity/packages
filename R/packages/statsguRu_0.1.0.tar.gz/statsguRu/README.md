# statsguRu
R Package for Visualising Cricket Statistics

Install the package in R using the following command:

`devtools::install_github("npranav10/statsguRu")`

You can install devtools using `install.packages("devtools")`

Visit the Shiny Application created using this package:
https://npranav10.shinyapps.io/statsguRu/

(P.S: The App is released in beta version.)
