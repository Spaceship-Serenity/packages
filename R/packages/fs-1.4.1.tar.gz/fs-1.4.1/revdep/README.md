# Platform

|field    |value                        |
|:--------|:----------------------------|
|version  |R version 3.6.1 (2019-07-05) |
|os       |macOS Catalina 10.15.3       |
|system   |x86_64, darwin15.6.0         |
|ui       |X11                          |
|language |(EN)                         |
|collate  |en_US.UTF-8                  |
|ctype    |en_US.UTF-8                  |
|tz       |America/New_York             |
|date     |2020-03-30                   |

# Dependencies

|package |old   |new        |Δ  |
|:-------|:-----|:----------|:--|
|fs      |1.3.2 |1.3.2.9000 |*  |
|Rcpp    |1.0.4 |NA         |*  |

# Revdeps

## Failed to check (1)

|package |version |error |warning |note |
|:-------|:-------|:-----|:-------|:----|
|vroom   |1.2.0   |1     |        |     |

