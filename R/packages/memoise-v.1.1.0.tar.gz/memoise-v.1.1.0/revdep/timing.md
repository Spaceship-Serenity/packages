# Check times

|   |package        |version | check_time|
|:--|:--------------|:-------|----------:|
|14 |regioneR       |1.6.2   |      734.7|
|1  |biolink        |0.1.2   |      443.1|
|20 |surveillance   |1.13.0  |      385.1|
|18 |SamplingStrata |1.1     |      306.7|
|9  |heemod         |0.9.0   |      268.7|
|17 |saeRobust      |0.1.0   |        251|
|10 |icd9           |1.3.1   |      143.4|
|13 |prcbench       |0.7.3   |        122|
|4  |devtools       |1.12.0  |      103.4|
|12 |OpenML         |1.3     |       87.3|
|15 |rgho           |1.0.1   |       62.6|
|3  |covr           |2.2.2   |       58.5|
|21 |toaster        |0.5.5   |       58.3|
|16 |RSQLite        |1.1-2   |       50.8|
|6  |GSED           |1.3     |       48.9|
|19 |SIDES          |1.10    |       47.7|
|2  |BWStest        |0.2.1   |       28.4|
|11 |opencage       |0.1.0   |       19.7|
|5  |functools      |0.2.0   |       14.5|
|8  |gWidgets2tcltk |1.0-5   |       10.4|
|7  |gWidgets2RGtk2 |1.0-5   |        5.3|


