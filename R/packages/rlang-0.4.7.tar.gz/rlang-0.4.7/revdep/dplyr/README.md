# Revdeps

## Failed to check (49)

|package                        |version |error  |warning |note |
|:------------------------------|:-------|:------|:-------|:----|
|ALA4R                          |?       |       |        |     |
|bibliometrix                   |3.0.2   |1      |        |     |
|CausalImpact                   |?       |       |        |     |
|CB2                            |?       |       |        |     |
|cbar                           |?       |       |        |     |
|NA                             |?       |       |        |     |
|choroplethr                    |3.6.3   |1      |        |     |
|CityWaterBalance               |0.1.0   |1      |        |     |
|CNVScope                       |?       |       |        |     |
|DecomposeR                     |1.0.2   |1      |        |     |
|dendroTools                    |1.0.7   |1      |        |     |
|edbuildmapr                    |0.2.0   |1      |        |     |
|EdSurvey                       |?       |       |        |     |
|EGAnet                         |0.9.3   |1      |        |     |
|EML                            |2.0.2   |1      |        |     |
|EstimateGroupNetwork           |0.2.2   |1      |        |     |
|EvaluateCore                   |0.1.1   |1      |        |     |
|gastempt                       |0.5.0   |1      |        |     |
|gesisdata                      |0.1.0   |1      |        |     |
|Greg                           |?       |       |        |     |
|NA                             |?       |       |        |     |
|ICAMS                          |?       |       |        |     |
|idiogramFISH                   |?       |       |        |     |
|[kuniezu](failures.md#kuniezu) |0.1.1   |__+1__ |        |-2   |
|manifestoR                     |1.4.0   |1      |        |     |
|MetaboList                     |2.0     |1      |        |     |
|MetaIntegrator                 |?       |       |        |     |
|MtreeRing                      |1.4.2   |1      |        |     |
|nesRdata                       |0.3.1   |1      |        |     |
|pmc                            |?       |       |        |     |
|NA                             |?       |       |        |     |
|ppcSpatial                     |0.2.0   |1      |        |     |
|PROsetta                       |0.1.4   |1      |        |     |
|provSummarizeR                 |?       |       |        |     |
|NA                             |?       |       |        |     |
|qgraph                         |1.6.5   |1      |        |     |
|r4lineups                      |0.1.1   |1      |        |     |
|rdflib                         |0.2.3   |1      |        |     |
|robmed                         |0.7.0   |1      |        |     |
|NA                             |?       |       |        |     |
|salesforcer                    |?       |       |        |     |
|SDLfilter                      |2.0.1   |1      |        |     |
|NA                             |?       |       |        |     |
|SimDesign                      |?       |       |        |     |
|thinkr                         |0.13    |1      |        |     |
|tidySEM                        |0.1.2   |1      |        |     |
|tmap                           |3.0     |1      |        |     |
|trackdf                        |?       |       |        |     |
|wrswoR                         |?       |       |        |     |

## New problems (1)

|package                                     |version |error  |warning |note |
|:-------------------------------------------|:-------|:------|:-------|:----|
|[dplyr.teradata](problems.md#dplyrteradata) |0.3.2   |__+1__ |        |1    |

