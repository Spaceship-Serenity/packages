# Revdeps

## Failed to check (9)

|package     |version |error |warning |note |
|:-----------|:-------|:-----|:-------|:----|
|bioOED      |?       |      |        |     |
|butcher     |?       |      |        |     |
|clustermole |?       |      |        |     |
|fishtree    |?       |      |        |     |
|metagam     |?       |      |        |     |
|omicwas     |?       |      |        |     |
|RNeXML      |?       |      |        |     |
|Seurat      |?       |      |        |     |
|trackr      |?       |      |        |     |

## New problems (1)

|package                      |version |error  |warning |note |
|:----------------------------|:-------|:------|:-------|:----|
|[tibble](problems.md#tibble) |3.0.2   |__+1__ |        |     |

