
## Test environments

* local OS X install: release
* travis-ci: 3.3, 3.4, 3.5, 3.6, 4.0, devel
* win-builder: devel and release
* rchk: unbuntu-rchk platform on R-hub


## R CMD check results

0 errors | 0 warnings | 0 notes


## Reverse dependencies

No problems were found.
