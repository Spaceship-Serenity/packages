#ifndef RLANG_REPLACE_NA_H
#define RLANG_REPLACE_NA_H


sexp* rlang_replace_na(sexp* x, sexp* replacement);


#endif
