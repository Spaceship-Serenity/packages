
#' Prettier formatting of quantities
#'
#' @docType package
#' @name prettyunits
NULL
