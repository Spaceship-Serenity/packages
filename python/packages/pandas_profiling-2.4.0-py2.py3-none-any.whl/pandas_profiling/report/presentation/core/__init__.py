from pandas_profiling.report.presentation.core.frequency_table import FrequencyTable
from pandas_profiling.report.presentation.core.frequency_table_small import (
    FrequencyTableSmall,
)
from pandas_profiling.report.presentation.core.html import HTML
from pandas_profiling.report.presentation.core.sequence import Sequence
from pandas_profiling.report.presentation.core.image import Image
from pandas_profiling.report.presentation.core.preview import Preview
from pandas_profiling.report.presentation.core.table import Table
from pandas_profiling.report.presentation.core.overview import Overview
from pandas_profiling.report.presentation.core.dataset import Dataset
from pandas_profiling.report.presentation.core.sample import Sample
