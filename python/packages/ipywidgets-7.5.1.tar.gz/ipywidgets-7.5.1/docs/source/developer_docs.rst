Developer Docs
===============

The Jupyter widgets packages are developed in the `https://github.com/jupyter-widgets/ipywidgets <https://github.com/jupyter-widgets/ipywidgets>`_ git repository.

.. toctree::
   :maxdepth: 3

   dev_install.md
   dev_testing.md
   dev_docs
   dev_release.md
