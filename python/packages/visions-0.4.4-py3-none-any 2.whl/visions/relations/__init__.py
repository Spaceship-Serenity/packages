"""This module contains (predefined) relations."""
from visions.relations.relations import (
    InferenceRelation,
    IdentityRelation,
    TypeRelation,
)
