"""Abstract classes for the report presentation"""
