"""Version, used in module and setup.py.
"""
__version__ = "2.4.5"
