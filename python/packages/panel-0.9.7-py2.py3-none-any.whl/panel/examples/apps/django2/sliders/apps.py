from django.apps import AppConfig

class SlidersConfig(AppConfig):
    name = 'sliders'
