#!/bin/bash
# do nothing for now
ls -alLR ${CACHE_PREFIX}