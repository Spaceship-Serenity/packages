Changes for 0.61
================

.. code-block:: text

  canvas.connect is now deprecated for event handling.  use
  mpl_connect and mpl_disconnect instead.  The callback signature is
  func(event) rather than func(widget, event)
