***************************
``matplotlib.font_manager``
***************************

.. automodule:: matplotlib.font_manager
   :members:
   :undoc-members:
   :show-inheritance:



