Exceptions
==========

.. automodule:: marshmallow.exceptions
    :members:
