# Contributing

We follow the [IPython Contributing Guide](https://github.com/ipython/ipython/blob/master/CONTRIBUTING.md).

See the [README](https://github.com/jupyter/jupyter_client/blob/master/README.md) on how to set up a development environment.
