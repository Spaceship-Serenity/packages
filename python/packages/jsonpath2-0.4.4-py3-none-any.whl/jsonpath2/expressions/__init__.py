#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Expressions used in jsonpath module."""
