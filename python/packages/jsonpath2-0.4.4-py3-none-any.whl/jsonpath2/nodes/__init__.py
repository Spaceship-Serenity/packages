#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Nodes module contains all the node definitions."""
