Contributing to Curio
=====================

As a general rule, The Curio project does not accept pull requests
except by invitation.  However, if you have found a bug, a typo, or
have ideas for improvement, please submit an issue instead.
