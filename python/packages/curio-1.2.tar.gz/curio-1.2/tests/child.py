import time

for i in range(4, 0, -1):
    print('t-minus', i, flush=True)
    time.sleep(1)
