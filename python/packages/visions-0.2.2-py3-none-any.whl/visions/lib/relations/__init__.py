"""This module contains predefined relations that can be commonly used, but are not default."""
