import wget
wget.usage()