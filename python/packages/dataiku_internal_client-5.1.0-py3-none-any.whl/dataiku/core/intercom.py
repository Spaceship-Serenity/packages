import os
import requests
import json
import os.path as osp
from dataiku.core import base
from dataiku.base import remoterun
import logging

_cached_location_data = None
_cached_session = None

def set_remote_dss(url, api_key, no_check_certificate=False):
    global _cached_location_data
    _cached_location_data = {
        "has_a_jek" : False,
        "backend_url": url,
        "auth_mode": "API_KEY",
        "api_key": api_key,
        "no_check_certificate" : no_check_certificate
    }
    create_session_if_needed()

def create_session_if_needed():
    global _cached_location_data, _cached_session
    _cached_session = requests.Session()
    if _cached_location_data.get("no_check_certificate", False):
        _cached_session.verify = False

def get_location_data():
    global _cached_location_data, _cached_session
    if _cached_location_data is not None:
        create_session_if_needed()
        return _cached_location_data

    api_ticket = remoterun.get_env_var("DKU_API_TICKET", d=None)

    if api_ticket is not None:
        # We have an API ticket so we are in DSS
        _cached_location_data = {
            "auth_mode": "TICKET",
            "api_ticket": api_ticket
        }

        _cached_location_data["backend_url"] = "http://%s:%s" % \
                            (remoterun.get_env_var("DKU_BACKEND_HOST", "127.0.0.1"),
                                remoterun.get_env_var("DKU_BACKEND_PORT"))

        if os.getenv("DKU_SERVER_KIND", "BACKEND") == "BACKEND":
            _cached_location_data["has_a_jek"] = False
        else:
            _cached_location_data["has_a_jek"] = True
            _cached_location_data["jek_url"] = "http://%s:%s" % (os.getenv("DKU_SERVER_HOST", "127.0.0.1"),
                                            int(os.getenv("DKU_SERVER_PORT")))

    else:
        # No API ticket so we are running outside of DSS, start the dance to find remote DSS authentication
        # info
        # In that order:
        #   - dataiku.set_remote_dss (has been handled at the top of this method)
        #   - Environment variables DKU_DSS_URL, DKU_API_KEY, DKU_NO_CHECK_CERTIFICATE
        #   - ~/.dataiku/config.json (with optional DKU_DEFAULT_INSTANCE environment variable to set the default instance)

        if os.getenv("DKU_DSS_URL") is not None:
            no_check_cert_env_var = os.getenv("DKU_NO_CHECK_CERTIFICATE")
            no_check_certificate = bool(no_check_cert_env_var) and no_check_cert_env_var.lower() != 'false'

            set_remote_dss(os.environ["DKU_DSS_URL"], os.environ["DKU_API_KEY"], no_check_certificate)
        else:
            config_file = osp.expanduser("~/.dataiku/config.json")
            if osp.isfile(config_file):
                with open(config_file) as f:
                    config = json.load(f)

                if os.getenv("DKU_DEFAULT_INSTANCE") is None:
                    default_instance_name = config["default_instance"]
                else:
                    default_instance_name = os.getenv("DKU_DEFAULT_INSTANCE")

                instance_details = config["dss_instances"][default_instance_name]

                set_remote_dss(instance_details["url"], instance_details["api_key"],
                                no_check_certificate = instance_details.get("no_check_certificate", False))
            else:
                raise Exception("No DSS URL or API key found from any location")

    create_session_if_needed()

    return _cached_location_data

def get_auth_headers():
    location_data = get_location_data()

    if location_data["auth_mode"] == "TICKET":
        headers = {"X-DKU-APITicket": location_data["api_ticket"]}
    else:
        auth = requests.auth.HTTPBasicAuth(location_data["api_key"], "")
        fake_req = requests.Request()
        auth(fake_req)
        headers = fake_req.headers

    if remoterun.has_env_var("DKU_CALL_ORIGIN"):
        headers['X-DKU-CallOrigin'] = remoterun.get_env_var("DKU_CALL_ORIGIN")

    return headers

def get_backend_url():
    return get_location_data()["backend_url"]

def get_jek_url():
    location_data = get_location_data()
    assert(location_data["has_a_jek"])
    return location_data["jek_url"]

def has_a_jek():
    return get_location_data()["has_a_jek"]

def backend_api_post_call(path, data, **kwargs):
    """For read-only calls that can go directly to the backend"""
    get_location_data() # Make sure _cached_session is initialized
    return _cached_session.post("%s/dip/api/tintercom/%s" % (get_backend_url(), path),
            data = data,
            headers = get_auth_headers(),
            **kwargs)

def jek_api_post_call(path, data, **kwargs):
    """For read-only calls that go directly to the jek"""
    get_location_data() # Make sure _cached_session is initialized
    return _cached_session.post("%s/kernel/tintercom/%s" % (get_jek_url(), path),
            data = data,
            headers = get_auth_headers(),
            **kwargs)

def backend_api_get_call(path, data, **kwargs):
    """For read-only calls that can go directly to the backend"""
    get_location_data() # Make sure _cached_session is initialized
    return _cached_session.get("%s/dip/api/tintercom/%s" % (get_backend_url(), path),
            data = data,
            headers = get_auth_headers(),
            **kwargs)

def jek_api_get_call(path, data, **kwargs):
    """For read-only calls that can go directly to the jek"""
    get_location_data() # Make sure _cached_session is initialized
    return _cached_session.get("%s/kernel/tintercom/%s" % (get_jek_url(), path),
            data = data,
            headers = get_auth_headers(),
            **kwargs)

def backend_api_put_call(path, data, **kwargs):
    """For read-only calls that can go directly to the backend"""
    get_location_data() # Make sure _cached_session is initialized
    return _cached_session.put("%s/dip/api/tintercom/%s" % (get_backend_url(), path),
            data = data,
            headers = get_auth_headers(),
            **kwargs)

# exposed methods for:
# * backend_... : call on the backend
# * jek_... : call on the jek only
# * jek_or_backend_... : call on the jek or backend depending on what is in the env vars
# variants:
# * ..._json_... : post request and then parse the response as json, handling errors
# * ..._get_... : get request and then parse the response as json, handling errors
# * ..._void_... : post request and then ignore the response, handling errors
# * ..._json_... : post request and then returns the raw response as stream, handling errors
# * ..._put_... : put request and then ignore the response, handling errors

def backend_json_call(path, data=None, err_msg=None, **kwargs):
    return _handle_json_resp(backend_api_post_call(path, data, **kwargs), err_msg = err_msg)

def jek_json_call(path, data=None, err_msg=None, **kwargs):
    return _handle_json_resp(jek_api_post_call(path, data, **kwargs), err_msg = err_msg)

def jek_or_backend_json_call(path, data=None, err_msg=None, **kwargs):
    if has_a_jek():
        return jek_json_call(path, data, err_msg, **kwargs)
    else:
        return backend_json_call(path, data, err_msg, **kwargs)

def backend_get_call(path, data=None, err_msg=None, **kwargs):
    return _handle_json_resp(backend_api_get_call(path, data, **kwargs), err_msg = err_msg)

def jek_get_call(path, data=None, err_msg=None, **kwargs):
    return _handle_json_resp(jek_api_get_call(path, data, **kwargs), err_msg = err_msg)

def jek_or_backend_get_call(path, data=None, err_msg=None, **kwargs):
    if has_a_jek():
        return jek_get_call(path, data, err_msg, **kwargs)
    else:
        return backend_get_call(path, data, err_msg, **kwargs)

def backend_void_call(path, data=None, err_msg=None, **kwargs):
    return _handle_void_resp(backend_api_post_call(path, data, **kwargs), err_msg = err_msg)

def jek_void_call(path, data=None, err_msg=None, **kwargs):
    return _handle_void_resp(jek_api_post_call(path, data, **kwargs), err_msg = err_msg)

def jek_or_backend_void_call(path, data=None, err_msg=None, **kwargs):
    if has_a_jek():
        return jek_void_call(path, data, err_msg, **kwargs)
    else:
        return backend_void_call(path, data, err_msg, **kwargs)
    
def backend_stream_call(path, data=None, err_msg=None, **kwargs):
    return _handle_stream_resp(backend_api_post_call(path, data, stream=True, **kwargs), err_msg = err_msg)

def jek_stream_call(path, data=None, err_msg=None, **kwargs):
    return _handle_stream_resp(jek_api_post_call(path, data, stream=True, **kwargs), err_msg = err_msg)

def jek_or_backend_stream_call(path, data=None, err_msg=None, **kwargs):
    if has_a_jek():
        return jek_stream_call(path, data, err_msg, **kwargs)
    else:
        return backend_stream_call(path, data, err_msg, **kwargs)

def backend_put_call(path, data=None, err_msg=None, **kwargs):
    return _handle_void_resp(backend_api_put_call(path, data, **kwargs), err_msg = err_msg)

# Error handling helpers

def _get_error_message(err_data):
    json_err = json.loads(err_data)
    if "detailedMessage" in json_err:
        return json_err["detailedMessage"]
    if "message" in json_err:
        return json_err["message"]
    return "No details"

def _handle_json_resp(resp, err_msg="Call failed"):
    if resp.status_code==200 or resp.status_code == 204:
        return json.loads(resp.text)
    else:
        err_data = resp.text
        if err_data:
            raise Exception("%s: %s" % (err_msg, _get_error_message(err_data).encode("utf8")))
        else:
            raise Exception("%s: %s" % (err_msg, "No details"))

def _handle_void_resp(resp, err_msg="Call failed"):
    if resp.status_code==200 or resp.status_code == 204:
        return None
    else:
        err_data = resp.text
        if err_data:
            raise Exception("%s: %s" % (err_msg, _get_error_message(err_data).encode("utf8")))
        else:
            raise Exception("%s: %s" % (err_msg, "No details"))

def _handle_stream_resp(resp, err_msg="Call failed"):
    if resp.status_code==200:
        return resp.raw
    else:
        err_data = resp.text
        if err_data:
            raise Exception("%s: %s" % (err_msg, _get_error_message(err_data).encode("utf8")))
        else:
            raise Exception("%s: %s" % (err_msg, "No details"))