from dataiku.base import remoterun

def default_project_key():
    if remoterun.has_env_var("DKU_CURRENT_PROJECT_KEY"):
        return remoterun.get_env_var("DKU_CURRENT_PROJECT_KEY")
    else:
        raise Exception("Default project key is not specified (no DKU_CURRENT_PROJECT_KEY in env)")

