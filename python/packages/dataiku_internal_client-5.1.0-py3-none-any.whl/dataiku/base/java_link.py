import socket, struct, json, logging
from io import RawIOBase
import os

class LinkedInputStream(RawIOBase):
    def __init__(self, link):
        self.link = link
        self.b = None
        self.used = 0
        self.reached_eof = False
    
    def readable(self):
        return True
        
    def next_block(self):
        if self.link is None:
            raise Exception('Not connected to the java side')
        if self.reached_eof:
            return None
        self.b = self.link.read_block()
        self.used = 0
        
    def readinto(self, b):
        n = len(b)
        if n == 0:
            return 0
        if self.b is None or self.used >= len(self.b):
            self.next_block()
        # eof
        if self.b is None:
            self.reached_eof = True
            return 0
        pos = self.used
        left = len(self.b) - pos
        l = min(n, left) if n > 0 else left
        self.used = self.used + l
        b[0:l] = self.b[pos:pos+l]
        return l        
        
    def __enter__(self):
        return self
    
    def __exit__(self, type, value, tb):
        self.flush()
        
class LinkedOutputStream(RawIOBase):
    """Unbuffered stream to the backend"""
    def __init__(self, link):
        self.link = link
        self.buffer = bytearray()
    
    def writable(self):
        return True
        
    def write(self, b):
        if len(b) > 0:
            self.buffer += b
            if len(self.buffer) >= 1024 * 1024:
                self.flush()
        
    def flush(self):
        if len(self.buffer) > 0:
            self.link.send_block(self.buffer)
            self.buffer = bytearray()
            
    def __enter__(self):
        return self
    
    def __exit__(self, type, value, tb):
        self.flush()

class JavaLink(object):
    """
    Link to the backend over a socket
    """
    def __init__(self, port, secret):
        self.secret = secret
        self.s = None
        self.port = port
        self.input = None
        self.output = None
        
    def connect(self):
        """Initiate connection"""
        logging.info("Connecting to parent at port %s" % self.port)
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.s.connect((os.getenv("DKU_BACKEND_HOST", "localhost"),self.port))
        self.send_string(self.secret)
        self.input = LinkedInputStream(self)
        self.output = LinkedOutputStream(self)
        logging.info("Connected to parent at port %s" % self.port)
        
    def close(self):
        """Close the socket (use send_string('') to send end of stream to backend)"""
        if self.s is None:
            raise Exception('Not connected to the java side')
        if self.input is not None and not self.input.closed:
            self.input.close()
        if self.output is not None and not self.output.closed:
            self.output.close()
        self.s.shutdown(socket.SHUT_RDWR)
        self.s.close()
        self.s = None
        
    def get_command(self):
        """Get the command to process, as an object"""
        return json.loads(self.read_block().decode("utf-8"))
        
    def read_block(self):
        """Get the next block from the backend"""
        if self.s is None:
            raise Exception('Not connected to the java side')
        l = struct.unpack('>i', self.s.recv(4))[0] # the java side expects big-endian
        if l == 0:
            return None
        else:
            b = bytearray()
            while len(b) < l:
                r = self.s.recv(l - len(b))
                b += r
                if len(r) == 0:
                    raise Exception()
            return bytes(b)
    
    def send_block(self, b):
        """Send a block to the backend"""
        #logging.debug("Sending: %s (%s)" % (b, len(b)))
        if self.s is None:
            raise Exception('Not connected to the java side')
        if b is None:
            self.s.sendall(struct.pack('>i', 0))
        else:
            self.s.sendall(struct.pack('>i', len(b))) # the java side expects big-endian
            self.s.sendall(b)
        #logging.debug("Send done")
            
    def read_json(self):
        b = self.read_block()
        if b is None:
            return None
        return json.loads(b.decode("utf-8"))
            
    def send_json(self, o):
        self.send_block(json.dumps(o).encode("utf-8"))

    def send_string(self, s):
        self.send_block(s.encode("utf-8"))
        
    def get_input(self):
        """Get the data sent by the backend"""
        if self.s is None:
            raise Exception('Not connected to the java side')
        return self.input
    
    def get_output(self):
        """Get the stream to write the result to the backend"""
        if self.s is None:
            raise Exception('Not connected to the java side')
        return self.output
    
    def __enter__(self):
        return self
    
    def __exit__(self, type, value, tb):
        self.close()
