import json, logging, sys, cgi

if sys.version_info > (3,0):
    from urllib import parse as urlparse
    from socketserver import ThreadingMixIn
    from http.server import HTTPServer
    from http.server import SimpleHTTPRequestHandler
else:
    import urlparse
    from SocketServer import ThreadingMixIn
    from BaseHTTPServer import HTTPServer
    from SimpleHTTPServer import SimpleHTTPRequestHandler

def handle_generic_error(error, command=None, arg=None):
    logging.exception("API call failed : " + str(command))
    return {
        "code": "-1",
        "errorType": error.__class__.__name__,
        "message": str(error),
        "command": command,
        "arg": arg
    }


class ThreadingServer(ThreadingMixIn, HTTPServer):
    pass


class DSSKernelServer(object):
    def __init__(self, port, request_handler_clazz):
        self.server = ThreadingServer(('', port), request_handler_clazz)

    def get_port(self):
        return self.server.server_port

    def serve(self):
        self.server.serve_forever()

class KernelRequestHandler(SimpleHTTPRequestHandler):

    def send204(self):
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def sendJSON200(self, obj):
        data = json.dumps(obj)

        self.send_response(200)
        self.send_header('Content-type', 'application/json')

        if sys.version_info > (3,0):
            data = data.encode("utf-8")
        self.send_header('Content-Length', len(data))
        self.end_headers()
        self.wfile.write(data)

    def send500(self, err):
        data = json.dumps(handle_generic_error(err))

        if sys.version_info > (3,0):
            data = data.encode("utf-8")

        self.send_response(500)
        self.send_header('Content-type', 'application/json')
        self.send_header('Content-Length', len(data))
        self.end_headers()
        self.wfile.write(data)

    def parse_form(self):
        ctype, pdict = cgi.parse_header(self.get_header("content-type"))
        if ctype == 'multipart/form-data':
            if sys.version_info > (3,0):
                form = cgi.parse_multipart(self.rfile.decode("utf-8"), pdict, keep_blank_values=True)
            else:
                form = cgi.parse_multipart(self.rfile, pdict, keep_blank_values=True)
        else:
            length = self.get_content_length()
            d = self.rfile.read(length)
            if sys.version_info > (3,0):
                form = urlparse.parse_qs(d.decode("utf-8"))
            else:
                form = urlparse.parse_qs(d)
        return form

    def get_header(self, header):
        if sys.version_info > (3,0):
            if header in self.headers:
                return self.headers[header]
            else:
                return None
        else:
            return self.headers.getheader(header)

    def get_content_length(self):
        return int(self.get_header("content-length"))

    def read_body_json(self):
        if sys.version_info > (3,0):
            length = self.get_content_length()
            return json.loads(self.rfile.read(length).decode("utf-8"))
        else:
            length = self.get_content_length()
            return json.loads(self.rfile.read(length))
