from .detector_factory import DetectorFactory, PROFILES_DIRECTORY, detect, detect_langs
