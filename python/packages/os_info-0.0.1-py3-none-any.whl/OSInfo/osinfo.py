import platform
from psutil import cpu_freq, boot_time, virtual_memory, disk_usage, cpu_count, cpu_percent
import sys
import distro
from numexpr import cpuinfo
from columnar import columnar
from requests import get
from datetime import datetime


def main():
    flags = []
    flags = sys.argv[1:]
    if flags != []:
        if "-I" in flags or "--info" in flags or "-i" in flags:
            cpufreq = cpu_freq()
            boot_timez = datetime.fromtimestamp(boot_time()).strftime('%Y/%m/%d %H:%M')
            mem = virtual_memory()
            show_ip = False
            if "--show-ip" in flags:
                show_ip = True
                try:
                    ip = get('https://api.ipify.org').text
                except Exception:
                    ip = "Unable to get ip"
            headers = ["System Info", "CPU Info", "RAM Info", "Disk Info"]
            data = [
                ["OS: " + distro.name(),
                "Processor: "+cpuinfo.cpu.info[0]['model name'],
                "Total RAM: "+ str(round(mem.total / 1000000000, 2)) + "GB",
                "Total: " + str(round(disk_usage('/').total / 1000000000, 2)) + "GB",],

                ["Version: " + distro.version(pretty=True),
                "Total cores: " + str(cpu_count(logical=True)),
                "Free: "+str(round(mem.total / 1000000000, 2) - round(mem.used / 1000000000, 2)) + "GB",
                "Free: " + str(round(disk_usage('/').free / 1000000000, 2)) + "GB",],

                ["Hostname: "+platform.node(),
                f"Max Frequency: {cpufreq.max:.2f}Mhz",
                "Used: "+str(round(mem.used / 1000000000, 2)) + "GB",
                "Used: " + str(round(disk_usage('/').used / 1000000000, 2)) + "GB"],
                ["IP Address: "+ip if show_ip else f"Boot Time: {boot_timez}", f"Min Frequency: {cpufreq.min:.2f}Mhz", f"CPU Usage: {cpu_percent()}%", ""],
                [f"Boot Time: {boot_timez}" if show_ip else "", f"Current Frequency: {cpufreq.current:.2f}Mhz", "", ""],
            ]
            print("\x1b[34m"+columnar(data, headers, no_borders=True))


        if "--version" in flags and len(flags) == 1:
            print("OsInfo 0.1 built on linux-gnu")
        elif "--help" in flags and len(flags) == 1:
            print("Usage:\n\n--version, -V | Get the version of osinfo\n--info, -i | Get system infos\n--show-ip | Show the ip address in the infos\nExample: osinfo --i  --show-ip")
    else:
        print("Invalid Options\n\nCorrect Usage: `OSInfo --info`")


if __name__ == "__main__":
    main()
