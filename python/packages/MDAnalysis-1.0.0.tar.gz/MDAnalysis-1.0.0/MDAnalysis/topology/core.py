# -*- Mode: python; tab-width: 4; indent-tabs-mode:nil; coding:utf-8 -*-
# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4
#
# MDAnalysis --- https://www.mdanalysis.org
# Copyright (c) 2006-2017 The MDAnalysis Development Team and contributors
# (see the file AUTHORS for the full list of names)
#
# Released under the GNU Public Licence, v2 or any higher version
#
# Please cite your use of MDAnalysis in published work:
#
# R. J. Gowers, M. Linke, J. Barnoud, T. J. E. Reddy, M. N. Melo, S. L. Seyler,
# D. L. Dotson, J. Domanski, S. Buchoux, I. M. Kenney, and O. Beckstein.
# MDAnalysis: A Python package for the rapid analysis of molecular dynamics
# simulations. In S. Benthall and S. Rostrup editors, Proceedings of the 15th
# Python in Science Conference, pages 102-109, Austin, TX, 2016. SciPy.
# doi: 10.25080/majora-629e541a-00e
#
# N. Michaud-Agrawal, E. J. Denning, T. B. Woolf, and O. Beckstein.
# MDAnalysis: A Toolkit for the Analysis of Molecular Dynamics Simulations.
# J. Comput. Chem. 32 (2011), 2319--2327, doi:10.1002/jcc.21787
#
"""Common functions for topology building --- :mod:`MDAnalysis.topology.core`
==========================================================================

The various topology parsers make use of functions and classes in this
module. They are mostly of use to developers.

See Also
--------
:mod:`MDAnalysis.topology.tables`
  for some hard-coded atom information that is used by functions such as
  :func:`guess_atom_type` and :func:`guess_atom_mass`.

"""

from __future__ import print_function, absolute_import
import six

# Global imports
import os.path
import numpy as np
from collections import defaultdict

# Local imports
from . import tables
from .guessers import (
    guess_atom_element, guess_atom_type,
    get_atom_mass, guess_atom_mass, guess_atom_charge,
    guess_bonds, guess_angles, guess_dihedrals, guess_improper_dihedrals,
)
from ..core._get_readers import get_parser_for
from ..lib.util import cached

#tumbleweed
