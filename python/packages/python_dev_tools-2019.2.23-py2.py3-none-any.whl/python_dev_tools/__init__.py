# -*- coding: utf-8 -*-

"""Top-level package for Python Dev Tools."""

__author__ = """Vincent Poulailleau"""
__email__ = 'vpoulailleau@gmail.com'
__version__ = '2019.02.23'
