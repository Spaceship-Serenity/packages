from collections import namedtuple


Rectangle = namedtuple("Rectangle", "width height")
