export declare const is_ie: boolean;
export declare const is_mobile: boolean;
export declare const is_little_endian: boolean;
