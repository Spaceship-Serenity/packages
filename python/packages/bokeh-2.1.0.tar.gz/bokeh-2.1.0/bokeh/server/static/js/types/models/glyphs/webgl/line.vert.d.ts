export declare const vertex_shader: string;
