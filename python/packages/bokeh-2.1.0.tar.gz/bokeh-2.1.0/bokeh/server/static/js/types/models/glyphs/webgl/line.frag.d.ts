export declare const fragment_shader: string;
