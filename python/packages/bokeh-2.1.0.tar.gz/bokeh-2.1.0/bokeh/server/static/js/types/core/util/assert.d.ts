export declare class AssertionError extends Error {
}
export declare function assert(condition: boolean | (() => boolean), message?: string): asserts condition;
export declare function unreachable(): never;
