Friends of pygit2:

- `SourceHut <https://sourcehut.org>`_
- `Robert Szymczak <https://github.com/m451>`_

Add your name to the list, `become a friend of pygit2 <https://github.com/sponsors/jdavid>`_.
