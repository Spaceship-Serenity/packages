from .core import _start_tensorflow, start_tensorflow

__version__ = '0.0.2'
