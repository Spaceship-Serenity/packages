======================
 stevedore User Guide
======================

.. toctree::
   :glob:
   :maxdepth: 2

   patterns_loading
   patterns_enabling
   tutorial/index
   sphinxext
   essays/*
   history
