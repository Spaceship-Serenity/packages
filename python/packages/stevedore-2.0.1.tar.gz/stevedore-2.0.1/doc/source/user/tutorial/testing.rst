=========
 Testing
=========

.. describe using the TestManager for setting up application tests

.. seealso::

   * :class:`~stevedore.tests.manager.TestExtensionManager`
