=======
History
=======

2019.02.23 (2019-02-24)
------------------

* First release on PyPI.
