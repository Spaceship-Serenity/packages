"""Version specification."""

VERSION = (0, 12, 0)

__version__ = ".".join(map(str, VERSION))
