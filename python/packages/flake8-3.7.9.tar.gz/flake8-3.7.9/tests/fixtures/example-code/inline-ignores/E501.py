from some.module.that.has.nested.sub.modules import ClassWithVeryVeryVeryVeryLongName  # noqa: E501,F401

# ClassWithVeryVeryVeryVeryLongName()
