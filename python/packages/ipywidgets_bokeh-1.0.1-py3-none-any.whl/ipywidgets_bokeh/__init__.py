from .widget import IPyWidget

__version__ = "1.0.1"
