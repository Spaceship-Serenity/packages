version_info = (6, 1, 3)
__version__ = '.'.join(map(str, version_info))

protocol_version_info = (5, 3)
protocol_version = "%i.%i" % protocol_version_info
