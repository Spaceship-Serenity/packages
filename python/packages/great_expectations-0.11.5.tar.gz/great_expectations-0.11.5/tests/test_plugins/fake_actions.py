class TemporaryNoOpSummarizer(object):
    def render(self, input):
        return input


class DropAllVowelsSummarizer(object):
    def render(self, input):
        return input
