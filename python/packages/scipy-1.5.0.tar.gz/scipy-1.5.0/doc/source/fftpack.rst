.. automodule:: scipy.fftpack
   :no-members:
   :no-inherited-members:
   :no-special-members:
