.. _optimize.linprog-interior-point:

linprog(method='interior-point')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.linprog
   :impl: scipy.optimize._linprog._linprog_ip
   :method: interior-point
