"""Top-level package for Python Dev Tools."""

__author__ = """Vincent Poulailleau"""
__email__ = "vpoulailleau@gmail.com"
__version__ = "2020.02.05"
