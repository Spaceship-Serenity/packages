CODE_STEM = "T"
NAME = "flake8-fixme"
VERSION = "1.1.1"
