from .columnar import Columnar

columnar = Columnar()