from ..exceptions import GreatExpectationsTypeError


class InvalidRenderedContentError(GreatExpectationsTypeError):
    pass
