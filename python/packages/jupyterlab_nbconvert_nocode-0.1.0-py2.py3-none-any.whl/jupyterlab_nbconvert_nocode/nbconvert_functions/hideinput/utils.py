
ENV_VARS = {'publish': 'LANTERN_PUBLISH_TEMPLATE',
            'export_pdf': 'LANTERN_EXPORT_PDF_TEMPLATE',
            'export_html': 'LANTERN_EXPORT_HTML_TEMPLATE',
            'export_html_email': 'LANTERN_EXPORT_HTML_EMAIL_TEMPLATE'}
