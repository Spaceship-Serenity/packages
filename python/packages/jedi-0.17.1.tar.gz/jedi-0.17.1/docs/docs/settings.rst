.. include:: ../global.rst

Settings
========

.. automodule:: jedi.settings
