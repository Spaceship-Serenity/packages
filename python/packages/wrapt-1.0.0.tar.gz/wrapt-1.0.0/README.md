wrapt
=====

A Python module for decorators, wrappers and monkey patching.

For full documentation see:

  http://wrapt.readthedocs.org
