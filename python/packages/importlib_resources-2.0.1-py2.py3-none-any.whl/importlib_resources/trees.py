# for compatibility with 1.1, continue to expose as_file here.

from ._common import as_file


__all__ = ['as_file']
