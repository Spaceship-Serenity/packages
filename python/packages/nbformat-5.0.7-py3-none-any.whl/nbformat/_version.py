# Make sure to update package.json, too!
version_info = (5, 0, 7)
__version__ = '.'.join(map(str, version_info))
