# coding: latin_1
#pylint: disable=bad-continuation,invalid-name,missing-docstring

TOTO = ('Caf�', 'Caf�', 'Caf�')
