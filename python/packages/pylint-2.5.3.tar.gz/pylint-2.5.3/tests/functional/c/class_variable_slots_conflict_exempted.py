# pylint: disable=missing-docstring,too-few-public-methods
class Example:
    __slots__ = ["field"]
    field: int
