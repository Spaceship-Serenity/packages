"""Test preferred modules."""
# pylint: disable=unused-import

import json  # [preferred-module]
from re import search  # [preferred-module]
