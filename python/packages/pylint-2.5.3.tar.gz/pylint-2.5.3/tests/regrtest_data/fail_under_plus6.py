""""
    pylint score:  +6
"""

import os

path = '/tmp'
os.path.exists(path)
