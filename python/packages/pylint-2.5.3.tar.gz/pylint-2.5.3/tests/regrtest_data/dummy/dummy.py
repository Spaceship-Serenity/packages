# pylint: disable=missing-docstring
DUMMY = 42
