msgpack-python is renamed to just msgpack.

Install msgpack by ``pip install msgpack``.


