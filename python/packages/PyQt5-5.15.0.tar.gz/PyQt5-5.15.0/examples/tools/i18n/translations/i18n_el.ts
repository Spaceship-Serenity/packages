<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Αρχείο</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>Έ&amp;ξοδος</translation>
    </message>
    <message>
        <source>First</source>
        <translation>Πρώτο</translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation>Παράδειγμα διεθνοποίησης</translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation>Ισομετρική</translation>
    </message>
    <message>
        <source>Language: %1</source>
        <translation>Γλώσσα: %1</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Ελληνικά</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Πλάγια</translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation>Προοπτική</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>Δεύτερο</translation>
    </message>
    <message>
        <source>Third</source>
        <translation>Τρίτο</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Όψη</translation>
    </message>
    <message>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
