"""
This subpackage is intented for low-level extension developers and compiler
developers.  Regular user SHOULD NOT use code in this module.

This contains compilable utility functions that can interact directly with
the compiler to implement low-level internal code.
"""
