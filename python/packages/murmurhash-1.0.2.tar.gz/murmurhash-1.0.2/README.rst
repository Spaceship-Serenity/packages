Cython bindings for MurmurHash2
*******************************

.. image:: https://img.shields.io/travis/explosion/murmurhash/master.svg?style=flat-square&logo=travis
    :target: https://travis-ci.org/explosion/murmurhash
    :alt: Build Status
    
.. image:: https://img.shields.io/appveyor/ci/explosion/murmurhash/master.svg?style=flat-square&logo=appveyor
    :target: https://ci.appveyor.com/project/explosion/murmurhash
    :alt: Appveyor Build Status

.. image:: https://img.shields.io/pypi/v/murmurhash.svg?style=flat-square
    :target: https://pypi.python.org/pypi/murmurhash
    :alt: pypi Version

.. image:: https://img.shields.io/conda/vn/conda-forge/murmurhash.svg?style=flat-square
    :target: https://anaconda.org/conda-forge/murmurhash
    :alt: conda Version

.. image:: https://img.shields.io/badge/wheels-%E2%9C%93-4c1.svg?longCache=true&style=flat-square&logo=python&logoColor=white
    :target: https://github.com/explosion/wheelwright/releases
    :alt: Python wheels
