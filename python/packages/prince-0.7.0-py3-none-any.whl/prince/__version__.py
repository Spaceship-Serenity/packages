VERSION = (0, 7, 0)

__version__ = '.'.join(map(str, VERSION))
