---------------
blacklist_calls
---------------

.. automodule:: bandit.blacklists.calls
