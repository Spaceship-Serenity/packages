-----------------
blacklist_imports
-----------------

.. automodule:: bandit.blacklists.imports
