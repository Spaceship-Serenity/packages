----
html
----

.. automodule:: bandit.formatters.html
