---
xml
---

.. automodule:: bandit.formatters.xml
