------
custom
------

.. automodule:: bandit.formatters.custom
