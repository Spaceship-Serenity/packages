----
json
----

.. automodule:: bandit.formatters.json
