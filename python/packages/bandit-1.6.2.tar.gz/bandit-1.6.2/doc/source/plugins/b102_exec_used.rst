---------------
B102: exec_used
---------------

.. automodule:: bandit.plugins.exec
