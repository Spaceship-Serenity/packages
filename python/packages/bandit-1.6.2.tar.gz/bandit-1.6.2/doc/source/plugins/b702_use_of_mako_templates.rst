---------------------------
B702: use_of_mako_templates
---------------------------

.. automodule:: bandit.plugins.mako_templates
