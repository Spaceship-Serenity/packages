---------------------------------------------
B602: subprocess_popen_with_shell_equals_true
---------------------------------------------

.. currentmodule:: bandit.plugins.injection_shell

.. autofunction:: subprocess_popen_with_shell_equals_true
   :noindex:
