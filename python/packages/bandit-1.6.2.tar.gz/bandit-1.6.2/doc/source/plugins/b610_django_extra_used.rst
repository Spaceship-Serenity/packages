-----------------------
B610: django_extra_used
-----------------------

.. currentmodule:: bandit.plugins.django_injection_sql

.. autofunction:: django_extra_used
   :noindex:
