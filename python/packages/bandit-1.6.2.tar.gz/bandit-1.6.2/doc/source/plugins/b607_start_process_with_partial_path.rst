-------------------------------------
B607: start_process_with_partial_path
-------------------------------------

.. currentmodule:: bandit.plugins.injection_shell

.. autofunction:: start_process_with_partial_path
   :noindex:
