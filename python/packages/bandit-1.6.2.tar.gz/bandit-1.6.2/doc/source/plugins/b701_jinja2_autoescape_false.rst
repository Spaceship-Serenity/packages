-----------------------------
B701: jinja2_autoescape_false
-----------------------------

.. automodule:: bandit.plugins.jinja2_templates
