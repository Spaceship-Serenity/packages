------------------------------
B103: set_bad_file_permissions
------------------------------

.. automodule:: bandit.plugins.general_bad_file_permissions
