-----------------
B101: assert_used
-----------------

.. automodule:: bandit.plugins.asserts
