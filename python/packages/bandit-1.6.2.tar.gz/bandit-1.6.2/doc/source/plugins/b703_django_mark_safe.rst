----------------------
B703: django_mark_safe
----------------------

.. automodule:: bandit.plugins.django_mark_safe
