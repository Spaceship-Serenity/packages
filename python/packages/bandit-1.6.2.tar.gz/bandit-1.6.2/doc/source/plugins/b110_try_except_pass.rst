---------------------
B110: try_except_pass
---------------------

.. automodule:: bandit.plugins.try_except_pass
