------------------------
B611: django_rawsql_used
------------------------

.. currentmodule:: bandit.plugins.django_injection_sql

.. autofunction:: django_rawsql_used
   :noindex:
