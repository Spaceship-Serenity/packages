----------------------
B201: flask_debug_true
----------------------

.. automodule:: bandit.plugins.app_debug
