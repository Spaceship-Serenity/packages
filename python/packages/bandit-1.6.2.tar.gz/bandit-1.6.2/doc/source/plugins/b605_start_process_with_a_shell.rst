--------------------------------
B605: start_process_with_a_shell
--------------------------------

.. currentmodule:: bandit.plugins.injection_shell

.. autofunction:: start_process_with_a_shell
   :noindex:
