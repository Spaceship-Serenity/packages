------------------------------------------
B603: subprocess_without_shell_equals_true
------------------------------------------

.. currentmodule:: bandit.plugins.injection_shell

.. autofunction:: subprocess_without_shell_equals_true
   :noindex:
