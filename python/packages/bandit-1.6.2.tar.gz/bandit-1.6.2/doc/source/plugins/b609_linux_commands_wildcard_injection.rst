---------------------------------------
B609: linux_commands_wildcard_injection
---------------------------------------

.. automodule:: bandit.plugins.injection_wildcard
