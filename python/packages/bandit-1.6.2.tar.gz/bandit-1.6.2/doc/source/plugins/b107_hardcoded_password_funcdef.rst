--------------------------------
B107: hardcoded_password_default
--------------------------------

.. currentmodule:: bandit.plugins.general_hardcoded_password

.. autofunction:: hardcoded_password_default
   :noindex:
