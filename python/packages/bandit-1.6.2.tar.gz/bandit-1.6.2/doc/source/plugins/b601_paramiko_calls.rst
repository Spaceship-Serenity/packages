--------------------
B601: paramiko_calls
--------------------

.. automodule:: bandit.plugins.injection_paramiko
