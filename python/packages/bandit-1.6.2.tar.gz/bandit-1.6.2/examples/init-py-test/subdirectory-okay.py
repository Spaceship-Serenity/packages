# A sample test file in a subdirectory and its parents both containing
# an __init__.py file outlined in bug/1743042.
print('hopefully no vulnerabilities here')
