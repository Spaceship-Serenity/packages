from subprocess import Popen as pop
import hashlib as h
import hashlib as hh
import hashlib as hhh
import hashlib as hhhh
from pickle import loads as lp
import pickle as p

pop('/bin/gcc --version', shell=True)

h.md5('1')
hh.md5('2')
hhh.md5('3').hexdigest()
hhhh.md5('4')
lp({'key': 'value'})
