print('hopefully no vulnerabilities here')
