"""Base test suite."""
