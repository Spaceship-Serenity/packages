# coding: utf8
from __future__ import unicode_literals


"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.nl.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "Apple overweegt om voor 1 miljard een U.K. startup te kopen",
    "Autonome auto's verschuiven de verzekeringverantwoordelijkheid naar producenten",
    "San Francisco overweegt robots op voetpaden te verbieden",
    "Londen is een grote stad in het Verenigd Koninkrijk",
]
