# coding: utf8
from __future__ import unicode_literals

from ..punctuation import TOKENIZER_SUFFIXES


_suffixes = TOKENIZER_SUFFIXES
