# This file is imported from __init__.py and exec'd from setup.py

__version__ = "0.16.0"
