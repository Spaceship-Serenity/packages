"""SQL-database-specific object editing mechanism
"""
