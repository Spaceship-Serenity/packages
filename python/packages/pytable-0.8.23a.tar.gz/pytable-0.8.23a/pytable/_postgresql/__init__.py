"""Base code for PostgreSQL database drivers"""

