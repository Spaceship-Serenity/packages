Modifying environment variables
===============================

These functions allow you to temporarily modify the environment variables, which
is often useful for testing code that calls other processes.

.. currentmodule:: testpath

.. autofunction:: modified_env

.. autofunction:: temporary_env

.. autofunction:: make_env_restorer
