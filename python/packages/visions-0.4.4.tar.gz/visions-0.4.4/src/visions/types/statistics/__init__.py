"""Namespace for statistical types (e.g. nominal, ordinal, interval)"""
