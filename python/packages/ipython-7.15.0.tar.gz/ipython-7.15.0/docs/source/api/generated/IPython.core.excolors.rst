.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.excolors`
============================
.. automodule:: IPython.core.excolors

.. currentmodule:: IPython.core.excolors

1 Class
-------

.. autoclass:: Deprec
  :members:
  :show-inheritance:

  .. automethod:: __init__

1 Function
----------

.. autofunction:: IPython.core.excolors.exception_colors

