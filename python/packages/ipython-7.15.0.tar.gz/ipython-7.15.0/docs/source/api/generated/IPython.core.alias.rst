.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.alias`
=========================
.. automodule:: IPython.core.alias

.. currentmodule:: IPython.core.alias

4 Classes
---------

.. autoclass:: AliasError
  :members:
  :show-inheritance:

.. autoclass:: InvalidAliasError
  :members:
  :show-inheritance:

.. autoclass:: Alias
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: AliasManager
  :members:
  :show-inheritance:

  .. automethod:: __init__

1 Function
----------

.. autofunction:: IPython.core.alias.default_aliases

