.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.shellapp`
============================
.. automodule:: IPython.core.shellapp

.. currentmodule:: IPython.core.shellapp

1 Class
-------

.. autoclass:: InteractiveShellApp
  :members:
  :show-inheritance:
