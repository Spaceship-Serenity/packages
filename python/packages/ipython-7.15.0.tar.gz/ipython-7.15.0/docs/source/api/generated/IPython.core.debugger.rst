.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.debugger`
============================
.. automodule:: IPython.core.debugger

.. currentmodule:: IPython.core.debugger

3 Classes
---------

.. autoclass:: Tracer
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: Pdb
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: InterruptiblePdb
  :members:
  :show-inheritance:

6 Functions
-----------

.. autofunction:: IPython.core.debugger.make_arrow


.. autofunction:: IPython.core.debugger.BdbQuit_excepthook


.. autofunction:: IPython.core.debugger.BdbQuit_IPython_excepthook


.. autofunction:: IPython.core.debugger.strip_indentation


.. autofunction:: IPython.core.debugger.decorate_fn_with_doc


.. autofunction:: IPython.core.debugger.set_trace

