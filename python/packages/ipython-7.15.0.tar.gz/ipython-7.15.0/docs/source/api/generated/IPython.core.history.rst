.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.history`
===========================
.. automodule:: IPython.core.history

.. currentmodule:: IPython.core.history

4 Classes
---------

.. autoclass:: HistoryAccessorBase
  :members:
  :show-inheritance:

.. autoclass:: HistoryAccessor
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: HistoryManager
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: HistorySavingThread
  :members:
  :show-inheritance:

  .. automethod:: __init__

3 Functions
-----------

.. autofunction:: IPython.core.history.needs_sqlite


.. autofunction:: IPython.core.history.catch_corrupt_db


.. autofunction:: IPython.core.history.extract_hist_ranges

