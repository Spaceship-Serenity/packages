.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`lib.guisupport`
=============================
.. automodule:: IPython.lib.guisupport

.. currentmodule:: IPython.lib.guisupport

6 Functions
-----------

.. autofunction:: IPython.lib.guisupport.get_app_wx


.. autofunction:: IPython.lib.guisupport.is_event_loop_running_wx


.. autofunction:: IPython.lib.guisupport.start_event_loop_wx


.. autofunction:: IPython.lib.guisupport.get_app_qt4


.. autofunction:: IPython.lib.guisupport.is_event_loop_running_qt4


.. autofunction:: IPython.lib.guisupport.start_event_loop_qt4

