.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`testing.iptest`
=============================
.. automodule:: IPython.testing.iptest

.. currentmodule:: IPython.testing.iptest

4 Classes
---------

.. autoclass:: TestSection
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: ExclusionPlugin
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: StreamCapturer
  :members:
  :show-inheritance:

  .. automethod:: __init__

.. autoclass:: SubprocessStreamCapturePlugin
  :members:
  :show-inheritance:

  .. automethod:: __init__

5 Functions
-----------

.. autofunction:: IPython.testing.iptest.monkeypatch_xunit


.. autofunction:: IPython.testing.iptest.extract_version


.. autofunction:: IPython.testing.iptest.test_for


.. autofunction:: IPython.testing.iptest.check_exclusions_exist


.. autofunction:: IPython.testing.iptest.run_iptest

