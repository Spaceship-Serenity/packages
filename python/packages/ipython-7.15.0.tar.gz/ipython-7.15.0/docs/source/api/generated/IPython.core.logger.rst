.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`core.logger`
==========================
.. automodule:: IPython.core.logger

.. currentmodule:: IPython.core.logger

1 Class
-------

.. autoclass:: Logger
  :members:
  :show-inheritance:

  .. automethod:: __init__
