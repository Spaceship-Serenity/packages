.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.module_paths`
=================================
.. automodule:: IPython.utils.module_paths

.. currentmodule:: IPython.utils.module_paths

1 Function
----------

.. autofunction:: IPython.utils.module_paths.find_mod

