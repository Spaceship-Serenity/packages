.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`terminal.interactiveshell`
========================================
.. automodule:: IPython.terminal.interactiveshell

.. currentmodule:: IPython.terminal.interactiveshell

1 Class
-------

.. autoclass:: TerminalInteractiveShell
  :members:
  :show-inheritance:

  .. automethod:: __init__

2 Functions
-----------

.. autofunction:: IPython.terminal.interactiveshell.get_default_editor


.. autofunction:: IPython.terminal.interactiveshell.black_reformat_handler

