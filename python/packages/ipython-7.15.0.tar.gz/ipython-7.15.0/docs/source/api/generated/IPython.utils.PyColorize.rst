.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.PyColorize`
===============================
.. automodule:: IPython.utils.PyColorize

.. currentmodule:: IPython.utils.PyColorize

1 Class
-------

.. autoclass:: Parser
  :members:
  :show-inheritance:

  .. automethod:: __init__
