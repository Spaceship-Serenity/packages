.. AUTO-GENERATED FILE -- DO NOT EDIT!

:mod:`IPython`
==============
.. automodule:: IPython

.. currentmodule:: IPython

3 Functions
-----------

.. autofunction:: IPython.embed_kernel


.. autofunction:: IPython.start_ipython


.. autofunction:: IPython.start_kernel

