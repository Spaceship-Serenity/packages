.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.strdispatch`
================================
.. automodule:: IPython.utils.strdispatch

.. currentmodule:: IPython.utils.strdispatch

1 Class
-------

.. autoclass:: StrDispatch
  :members:
  :show-inheritance:

  .. automethod:: __init__
