.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`testing`
======================
.. automodule:: IPython.testing

.. currentmodule:: IPython.testing

1 Function
----------

.. autofunction:: IPython.testing.test

