.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`utils.process`
============================
.. automodule:: IPython.utils.process

.. currentmodule:: IPython.utils.process

1 Class
-------

.. autoclass:: FindCmdError
  :members:
  :show-inheritance:

2 Functions
-----------

.. autofunction:: IPython.utils.process.find_cmd


.. autofunction:: IPython.utils.process.abbrev_cwd

