.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`terminal.embed`
=============================
.. automodule:: IPython.terminal.embed

.. currentmodule:: IPython.terminal.embed

3 Classes
---------

.. autoclass:: KillEmbedded
  :members:
  :show-inheritance:

.. autoclass:: EmbeddedMagics
  :members:
  :show-inheritance:

.. autoclass:: InteractiveShellEmbed
  :members:
  :show-inheritance:

  .. automethod:: __init__

1 Function
----------

.. autofunction:: IPython.terminal.embed.embed

