Incompatible change switch to perl
----------------------------------

Document which filename start with ``incompat-`` will be gathers in their own
incompatibility section.

Starting with IPython 42, only perl code execution is allowed. See :ghpull:`42`
