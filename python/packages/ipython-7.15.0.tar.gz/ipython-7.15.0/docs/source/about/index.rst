.. _about_index:

=============
About IPython
=============

.. toctree::
   :maxdepth: 1

   history
   license_and_copyright

