#!/usr/bin/env python
"""
This is the most simple example possible.
"""
from prompt_toolkit import Application

app = Application(full_screen=False)
app.run()
